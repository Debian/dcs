#################################
# $Id: Makefile.test_pubmed_article.app 646947 2022-03-17 12:28:05Z ivanov $
#################################

APP = test_pubmed_article
SRC = test_pubmed_article
LIB = efetch pubmed medline biblio general xser xutil xncbi

LIBS = $(DL_LIBS) $(ORIG_LIBS)

WATCHERS = grichenk
