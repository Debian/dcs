/*  $Id: mask_writer_int.cpp 500404 2016-05-04 14:59:01Z camacho $
 * ===========================================================================
 *
 *                            PUBLIC DOMAIN NOTICE
 *               National Center for Biotechnology Information
 *
 *  This software/database is a "United States Government Work" under the
 *  terms of the United States Copyright Act.  It was written as part of
 *  the author's official duties as a United States Government employee and
 *  thus cannot be copyrighted.  This software/database is freely available
 *  to the public for use. The National Library of Medicine and the U.S.
 *  Government have not placed any restriction on its use or reproduction.
 *
 *  Although all reasonable efforts have been taken to ensure the accuracy
 *  and reliability of the software and data, the NLM and the U.S.
 *  Government do not and cannot warrant the performance or results that
 *  may be obtained by using this software or data. The NLM and the U.S.
 *  Government disclaim all warranties, express or implied, including
 *  warranties of performance, merchantability or fitness for any particular
 *  purpose.
 *
 *  Please cite the author in any work or product based on this material.
 *
 * ===========================================================================
 *
 * Author:  Aleksandr Morgulis
 *
 * File Description:
 *   CMaskWriterInt class member and method definitions.
 *
 */
#include <ncbi_pch.hpp>
#include <objtools/seqmasks_io/mask_writer_int.hpp>
#include <objects/seqloc/Seq_loc.hpp>


BEGIN_NCBI_SCOPE

//-------------------------------------------------------------------------
void CMaskWriterInt::Print( objects::CBioseq_Handle& bsh,
                               const TMaskList & mask,
                               bool parsed_id )
{
    PrintId( bsh, parsed_id );
    os << endl;
    PrintMasks(os, mask);
}

void CMaskWriterInt::PrintMasks(CNcbiOstream& os, const TMaskList& mask)
{
    ITERATE(TMaskList, i, mask) {
        os << i->first << " - " << i->second << "\n";
    }
}


END_NCBI_SCOPE
